//
//  AddEdit.swift
//  ToDoListAssignment1
//
//  Created by Мас on 20.01.2021.
//

import UIKit

class AddEdit: UIViewController {
    
    var delegate: ViewController?
    
    @IBOutlet weak var titleLabel: UITextField!
    @IBOutlet weak var descLabel: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    var indexPath: IndexPath?
    var task: Task?
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if indexPath != nil {
            titleLabel.text = task?.taskTitle
            descLabel.text = task?.taskDetail
            datePicker.date = (task?.taskDate)!
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func saveButtonPressed(_ sender: UIBarButtonItem) {
        delegate?.saveButtonPressed(from: self, with: titleLabel.text, and: descLabel.text, on: datePicker.date, sender: indexPath)
    }
    
    @IBAction func cancelButtonPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }

}

