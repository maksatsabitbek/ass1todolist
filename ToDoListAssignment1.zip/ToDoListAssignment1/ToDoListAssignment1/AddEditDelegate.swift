//
//  AddEditDelegate.swift
//  ToDoListAssignment1
//
//  Created by Мас on 20.01.2021.
//
    import Foundation
    import UIKit

    protocol AddEditDelegate: class {
        func saveButtonPressed(from: UIViewController, with title: String?, and desc: String?, on date: Date?, sender indexPath: IndexPath?)
    }
