

import Foundation
import UIKit

protocol AddOrEditItemVCDelegate: class {
    func saveButtonPressed(from: UIViewController, with title: String?, and desc: String?, on date: Date?, sender indexPath: IndexPath?)
}
